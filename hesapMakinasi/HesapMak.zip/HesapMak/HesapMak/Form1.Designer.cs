﻿namespace HesapMak
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBox1 = new TextBox();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            button11 = new Button();
            button12 = new Button();
            button13 = new Button();
            button14 = new Button();
            button15 = new Button();
            button16 = new Button();
            SuspendLayout();
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Verdana", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 162);
            textBox1.Location = new Point(18, 14);
            textBox1.Margin = new Padding(3, 4, 3, 4);
            textBox1.Name = "textBox1";
            textBox1.RightToLeft = RightToLeft.No;
            textBox1.Size = new Size(226, 31);
            textBox1.TabIndex = 0;
            textBox1.TextAlign = HorizontalAlignment.Right;
            // 
            // button1
            // 
            button1.BackColor = Color.Yellow;
            button1.Font = new Font("Verdana", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            button1.Location = new Point(18, 48);
            button1.Name = "button1";
            button1.Size = new Size(52, 50);
            button1.TabIndex = 1;
            button1.Text = "1";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.Yellow;
            button2.Font = new Font("Verdana", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            button2.Location = new Point(76, 48);
            button2.Name = "button2";
            button2.Size = new Size(52, 50);
            button2.TabIndex = 2;
            button2.Text = "2";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.Yellow;
            button3.Font = new Font("Verdana", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            button3.Location = new Point(134, 48);
            button3.Name = "button3";
            button3.Size = new Size(52, 50);
            button3.TabIndex = 3;
            button3.Text = "3";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.BackColor = Color.FromArgb(255, 128, 0);
            button4.Font = new Font("Verdana", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            button4.Location = new Point(192, 48);
            button4.Name = "button4";
            button4.Size = new Size(52, 50);
            button4.TabIndex = 4;
            button4.Text = "+";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.BackColor = Color.FromArgb(255, 128, 0);
            button5.Font = new Font("Verdana", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            button5.Location = new Point(192, 104);
            button5.Name = "button5";
            button5.Size = new Size(52, 50);
            button5.TabIndex = 8;
            button5.Text = "-";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // button6
            // 
            button6.BackColor = Color.Yellow;
            button6.Font = new Font("Verdana", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            button6.Location = new Point(134, 104);
            button6.Name = "button6";
            button6.Size = new Size(52, 50);
            button6.TabIndex = 7;
            button6.Text = "6";
            button6.UseVisualStyleBackColor = false;
            button6.Click += button6_Click;
            // 
            // button7
            // 
            button7.BackColor = Color.Yellow;
            button7.Font = new Font("Verdana", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            button7.Location = new Point(76, 104);
            button7.Name = "button7";
            button7.Size = new Size(52, 50);
            button7.TabIndex = 6;
            button7.Text = "5";
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click;
            // 
            // button8
            // 
            button8.BackColor = Color.Yellow;
            button8.Font = new Font("Verdana", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            button8.Location = new Point(18, 104);
            button8.Name = "button8";
            button8.Size = new Size(52, 50);
            button8.TabIndex = 5;
            button8.Text = "4";
            button8.UseVisualStyleBackColor = false;
            button8.Click += button8_Click;
            // 
            // button9
            // 
            button9.BackColor = Color.FromArgb(255, 128, 0);
            button9.Font = new Font("Verdana", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            button9.Location = new Point(192, 160);
            button9.Name = "button9";
            button9.Size = new Size(52, 50);
            button9.TabIndex = 12;
            button9.Text = "x";
            button9.UseVisualStyleBackColor = false;
            button9.Click += button9_Click;
            // 
            // button10
            // 
            button10.BackColor = Color.Yellow;
            button10.Font = new Font("Verdana", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            button10.Location = new Point(134, 160);
            button10.Name = "button10";
            button10.Size = new Size(52, 50);
            button10.TabIndex = 11;
            button10.Text = "9";
            button10.UseVisualStyleBackColor = false;
            button10.Click += button10_Click;
            // 
            // button11
            // 
            button11.BackColor = Color.Yellow;
            button11.Font = new Font("Verdana", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            button11.Location = new Point(76, 160);
            button11.Name = "button11";
            button11.Size = new Size(52, 50);
            button11.TabIndex = 10;
            button11.Text = "8";
            button11.UseVisualStyleBackColor = false;
            button11.Click += button11_Click;
            // 
            // button12
            // 
            button12.BackColor = Color.Yellow;
            button12.Font = new Font("Verdana", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            button12.Location = new Point(18, 160);
            button12.Name = "button12";
            button12.Size = new Size(52, 50);
            button12.TabIndex = 9;
            button12.Text = "7";
            button12.UseVisualStyleBackColor = false;
            button12.Click += button12_Click;
            // 
            // button13
            // 
            button13.BackColor = Color.FromArgb(255, 128, 0);
            button13.Font = new Font("Verdana", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            button13.Location = new Point(192, 216);
            button13.Name = "button13";
            button13.Size = new Size(52, 50);
            button13.TabIndex = 16;
            button13.Text = "/";
            button13.UseVisualStyleBackColor = false;
            button13.Click += button13_Click;
            // 
            // button14
            // 
            button14.BackColor = Color.FromArgb(0, 192, 0);
            button14.Font = new Font("Verdana", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            button14.Location = new Point(134, 216);
            button14.Name = "button14";
            button14.Size = new Size(52, 50);
            button14.TabIndex = 15;
            button14.Text = "=";
            button14.UseVisualStyleBackColor = false;
            button14.Click += button14_Click;
            // 
            // button15
            // 
            button15.BackColor = Color.Yellow;
            button15.Font = new Font("Verdana", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            button15.Location = new Point(76, 216);
            button15.Name = "button15";
            button15.Size = new Size(52, 50);
            button15.TabIndex = 14;
            button15.Text = "0";
            button15.UseVisualStyleBackColor = false;
            button15.Click += button15_Click;
            // 
            // button16
            // 
            button16.BackColor = Color.Cyan;
            button16.Font = new Font("Verdana", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            button16.Location = new Point(18, 216);
            button16.Name = "button16";
            button16.Size = new Size(52, 50);
            button16.TabIndex = 13;
            button16.Text = "C";
            button16.UseVisualStyleBackColor = false;
            button16.Click += button16_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 18F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Blue;
            ClientSize = new Size(257, 282);
            Controls.Add(button13);
            Controls.Add(button14);
            Controls.Add(button15);
            Controls.Add(button16);
            Controls.Add(button9);
            Controls.Add(button10);
            Controls.Add(button11);
            Controls.Add(button12);
            Controls.Add(button5);
            Controls.Add(button6);
            Controls.Add(button7);
            Controls.Add(button8);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(textBox1);
            Font = new Font("Verdana", 12F);
            Margin = new Padding(3, 4, 3, 4);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBox1;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button11;
        private Button button12;
        private Button button13;
        private Button button14;
        private Button button15;
        private Button button16;
    }
}
